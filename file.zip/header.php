<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale =1, maximum-scale=1, user-scalable=no" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<script src="js/jquery-1.12.0.min.js"></script>
<link rel="stylesheet" href="CSS/taCSS.css">
<script type="text/javascript">
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
	   function FnUpdate(id) {
	   		var e = document.getElementById(id); //console.log(id);
	   		var txt="textarea"+id; //console.log(txt);	      	
	      	var txtArea = document.getElementById(txt).value;
 	        $.ajax({
	        type : 'POST', //kiểu post
	        url  : 'xuly.php', //gửi dữ liệu sang trang xuly.php
	        data :  {	loai:'UPDATE',
	        			stt:id,
	        			sms: txtArea	        			
	        		}, 
	        success :  function(data)
	               {                        
	                    if(data == 'false'){
	                        alert('sai sai cai gi do');
	                    }else{
	                       document.getElementById(id).innerHTML="";
	                       document.getElementById(id).innerHTML=data;
	                       //console.log(data);
	                    }
	               }
	        }); 
	   }
	   function toggle_visibility(id) {
	       var e = document.getElementById(id); //console.log(id);
	       if(e.style.display == 'none')
	          e.style.display = 'block';
	       else
	          e.style.display = 'none';

	        $.ajax({
	        type : 'POST', 		//kiểu post
	        url  : 'xuly.php', 	//gửi dữ liệu sang trang xuly.php
	        data :  {	loai:'visible',
	        			stt: id,
	        			sms: e.style.display
	        		}, 
	        success :  function(data)
	               {                        
	                    // if(data == 'false')
	                    // {
	                    //     alert('sai sai cai gi do');
	                    // }else{
	                    //    document.getElementById(id).innerHTML="";
	                    //    document.getElementById(id).innerHTML=data;
	                    // }
	               }
	        }); 	      	
	   }

//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

</script>
</head>	
<body>
