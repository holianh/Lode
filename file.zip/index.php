
<?php
 include('header.php');// sau nay xong, copy noi dung file do vao day.

 setlocale(LC_TIME, "vn_VN");
 date_default_timezone_set('Asia/Ho_Chi_Minh');


include('taFuncs.php');		
//////////////////////////////////////////////////////////
$sKQ = array();
$sKQ_cnt=0; $k=1;
// $ColOPen='<tr><td>';
// $ColCLose='</td></tr>';

//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
function XuLy1muc(&$loai,$string){
$debug=0;
	//$string='de 97x8tr.';
		if($debug==1)echo $string.'<br/><br/>';
//Lấy số tiền, quy đổi ra nghìn (n):	
		$subject =$string;
		$s1_Open='#';
		$s5_Close='#imU';
		$s4_GiaTien=$GLOBALS['rgGiaTien'];
		$pattern = $s1_Open.$s4_GiaTien.$s5_Close;
		preg_match_all($pattern, $subject, $matches) ; 
		if($debug==1)print_r($matches);
	$tien=trim($matches[0][0]);
		$string=str_replace($tien,'.',$string);
		if($debug==1)echo $tien.'<br/>';
		$tien=str_replace('tr','000n',$tien);
		$string=str_replace($tien,';',$string);
		$tien=str_replace('x','*',$tien);
		$tien=str_replace('.','',$tien);
		if(substr($tien,-1)=='0')$tien=$tien.'n'; // Nếu cuối xâu k có đơn vị: gán = 'n'
		if($debug==1)echo $string.'<br/>';
		
//Lấy đoạn ký tự đầu tiên:	
		$subject =$string;	
		$s3_DaySo='^[a-z\W]*(?=\d)';// *+ lấy hết, '^[a-z\W]*(?=\d)';
		$pattern = $s1_Open.$s3_DaySo.$s5_Close;
		preg_match_all($pattern, $subject, $matches) ; 
		if($debug==1)print_r($matches);		
	$Chu=trim($matches[0][0]);
		$string=str_replace($Chu,'.',$string);
		if($debug==1)echo $Chu.'<br/>';
		if($debug==1)echo $string.'<br/>';

// Tách Số:		
		$subject =$string;
		$s3='\d+(?=\W)';
		$pattern = $s1_Open.$s3.$s5_Close;
		preg_match_all($pattern, $subject, $matches) ; 
		if($debug==1)print_r($matches[0]);
		
		if($loai==''){$loai='de';}
		$vt='-'.$Chu;
		if(strpos($vt,'de')>0)		$loai='de';
		if(strpos($vt,'lo')>0)		$loai='lo';
		if(strpos($vt,'cang')>0)	$loai='ba cang';
		if(strpos($vt,'xien')>0)	{$loai='xien';} // cần xử lý: xien, xien 2, xien 3, xien 4, xien2, xien3, xien4
		if(strpos($vt,'dau dit')>0)		$loai='(---Can xu ly---)';
		if(strpos($vt,'he')>0)		$loai='(---Can xu ly---)';
		
		//echo '@'.$vt.'@'; 	
		$cnt=count($matches[0]);
		$Sout='';
			//echo $Chu.':'; //print_r($matches[0]);
		if($loai=='de'){//-----------------------------------------
			foreach($matches[0] as $so) {
				$so=trim($so);
				$sosau='';
				if(strlen($so)==3){
						$sosau	=substr($so,1,2); // Lấy 2 số cuối;
						$so		=substr($so,0,2); // Lấy 2 số đầu;
						$Sout=$Sout.$so.', '.$sosau.',';
						$cnt=$cnt+1;
				}else{
						$Sout=$Sout.$so.', ';
					 }
			}
		}
		if(($loai=='lo')|($loai=='ba cang')){//-----------------------------------------
			foreach($matches[0] as $so) {
				$so=trim($so);
				$Sout=$Sout.$so.',';
				
			}
		}
		if($loai=='xien'){//-----------------------------------------
			foreach($matches[0] as $so) {
				$so=trim($so);
				$Sout=$Sout.$so.',';				
			}
		}
		
		$Sout=substr_replace($Sout, '', -1);// remove last char: , 
		$Sout=$Sout.' '.$tien;
		$Sout='('.$loai.'.'.$cnt.'so:'.$Sout.')';
		if($debug==1)echo $Sout.'<br/>';
		return $Sout;
}// Cách dùng: $Sout=XuLy1muc($loai,$string);
//XuLy1muc('lo45 50 x20d ');
//return;

 
echo date("l jS \of F Y h:i:s A")."<br/><br/>";
//echo '<table width="90%">';
$SMS_cnt=0;
//echo '<table class="table table-striped table-bordered" id="example">';
 foreach (glob("./Data/*.xml") as $filename) {
	$subject = file_get_contents($filename);
	$pattern = '#(?<=body=")(.*)(?=" toa=)#imU';
	preg_match_all($pattern, $subject, $matches, PREG_OFFSET_CAPTURE, 3);
	foreach ( $matches[0] as $str){
		if(strpos($str[0], "x")){ //echo $k[0].'<br/><br/>';
			 
////////////////////////////////////////////////
			//$file=vn_str_filter($file)
			$string = $str[0];
// Debug gia tien:			
			// if($SMS_cnt==2){
			// 		$string = ChuanHoaCau($string,$SMS_cnt);
			// }else
			{
					$string = ChuanHoaCau($string);
			}
			$string0=$string; // Ddự trữ xâu gốc để phân tách thành các cụm
			
			$subject = $string;
			
			$s1_Open='#';
			$s2_KeyWord=$GLOBALS['rgKeyWord']; 
			$s3_DaySo=$GLOBALS['rgDaySo'];//'[0-9\W]*';
			$s4_GiaTien=$GLOBALS['rgGiaTien'];//'x\s*[\d]+\s*[dntrkgd]*\W';//'x[\W]?[\d]+[\W]*[ndktr]*\W';//'[x][\W]?[\d]+[\S]?(k|n|tr|d)?\W';
			$s5_Close='#imU';
			
			$pattern = $s1_Open.$s2_KeyWord.$s3_DaySo.$s4_GiaTien.$s5_Close;
			preg_match_all($pattern, $subject, $matches) ;
			
			// echo $matches[0][0];
			$cnt=0;
			foreach($matches[0] as $s){
				$cnt++;
				 if($k%2==0) $string=str_replace($s,'<span class="vang">'.$s.'</span>',$string);
				 else 		 $string=str_replace($s,'<span class="xanh">'.$s.'</span>',$string);
				 $k=$k+1;
			 }
			 if($cnt>=0){
			 	$SMS_cnt++ ;
			 	if($SMS_cnt<10){$IDdisplay="sms0".$SMS_cnt;}else{$IDdisplay="sms".$SMS_cnt;}
			 	//echo'<tr><td>';
			 	
			 	 echo "<input type='button' class='btn' name='$IDdisplay' value='{$IDdisplay}' onclick=toggle_visibility('$IDdisplay');>";
			 	 echo "<div id='$IDdisplay' style={width:95%}>
			 	 			<form type='submit' style='width: 95%'> ";
				  			echo "<textarea class='form-control' id='textarea$IDdisplay' rows='4' style='min-width: 90%'>{$str[0]}</textarea><br/>";
				  			echo "<input type='button' class='btn' name='Cap nhat $IDdisplay' value='Cap nhat $IDdisplay' onclick=FnUpdate('$IDdisplay');><br/>";  
				 			echo $string;
				 			echo '<br/>('.strlen($string).':ký tự)'; 
				  			$arr= SMS2array($string0);
				  			echo "<center><input type='button' class='btn' name='btn$IDdisplay' value='Hide $IDdisplay' onclick=toggle_visibility('$IDdisplay');></center></form>";				 	 
?>
							
						</div>
				
<?php		
			 }
//			 $sKQ[$sKQ_cnt]= $string;
			 $sKQ_cnt++;			 
			 if($sKQ_cnt>100)return; // ngừng khi in ra 10 KQ đê xem
////////////////////////////////////////////////
		}
	}
}
//echo '</table>';
//echo '</table>';
//print_r($sKQ_cnt);
 return;

 //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

?>


<?php
	$stt=1;
 
	foreach (glob("./Data/*.xml") as $filename) {
	    //echo "$filename   <br/><br/>";
		$get = file_get_contents($filename);
	 
		$subject = $get;
		$pattern = '#(?<=body=")(.*)(?=" toa=)#imU';

		preg_match_all($pattern, $subject, $matches, PREG_OFFSET_CAPTURE, 3);
		//print_r($matches);

		//echo '<center><table border=1 width=90% >';
		
		foreach ( $matches[0] as $k){
			 if(strpos($k[0], "x")){	//			 echo '<tr><td>'.$stt.'</td><td>'.$k[0].'</td></tr>';
				echo $k[0];
				echo '<br/><br/>';
				$stt=$stt+1;
			 }
		 }
		echo '</table></center>';
	}

///////////////////////////////////////////////////////////////
//--------------------------------------------------------------------------
//hàm đổi chữ TV có dấu ==> không dấu
	function vn_str_filter ($str){
        $unicode = array(
            'a'=>'á|à|ả|ã|ạ|ă|ắ|ặ|ằ|ẳ|ẵ|â|ấ|ầ|ẩ|ẫ|ậ',
            'd'=>'đ|₫',
            'e'=>'é|è|ẻ|ẽ|ẹ|ê|ế|ề|ể|ễ|ệ', //mã gõ trên PC
			'e'=>'ệ|ề|ề|ế|ẻ|é|ê|é|ể|ệ',		  // Mã gõ trên phone, PC không xử lý được	
            'i'=>'í|ì|ỉ|ĩ|ị',
			'i'=>'í|í|ì',  //TA
            'o'=>'ó|ò|ỏ|õ|ọ|ô|ố|ồ|ổ|ỗ|ộ|ơ|ớ|ờ|ở|ỡ|ợ',
			'o'=>'ổ|ô|ó|ố',  //TA
            'u'=>'ú|ù|ủ|ũ|ụ|ư|ứ|ừ|ử|ữ|ự',
            'y'=>'ý|ỳ|ỷ|ỹ|ỵ',
			'A'=>'Á|À|Ả|Ã|Ạ|Ă|Ắ|Ặ|Ằ|Ẳ|Ẵ|Â|Ấ|Ầ|Ẩ|Ẫ|Ậ',
            'D'=>'Đ',
            'E'=>'É|È|Ẻ|Ẽ|Ẹ|Ê|Ế|Ề|Ể|Ễ|Ệ',
            'I'=>'Í|Ì|Ỉ|Ĩ|Ị',
            'O'=>'Ó|Ò|Ỏ|Õ|Ọ|Ô|Ố|Ồ|Ổ|Ỗ|Ộ|Ơ|Ớ|Ờ|Ở|Ỡ|Ợ',
            'U'=>'Ú|Ù|Ủ|Ũ|Ụ|Ư|Ứ|Ừ|Ử|Ữ|Ự',
            'Y'=>'Ý|Ỳ|Ỷ|Ỹ|Ỵ',
        );
       foreach($unicode as $nonUnicode=>$uni){
            $str = preg_replace("/($uni)/i", $nonUnicode, $str);  
       } 
		return $str;
    }
// Sử dụng:   $file=vn_str_filter($file);
//--------------------------------------------------------------------------
?>

</body>
</html>


<?php
/*
echo "<div id='$IDdisplay' style={width:95%}><form type='submit' style='width: 95%'> ";//' style="display: none;">';



*/
?>
