<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
	span.vang { background-color: yellow; }
	span.xanh { background-color: cyan; }
	table, th, td {
		border: 1px solid lightgray;
		border-collapse: collapse;
	}
	.rowOdd { background-color: #f4fcfc; }
	.rowEven { background-color: #f2f1d5; }
</style>
</head>
<body>

<?php
$rgDaySo='[0-9\W]*';
$rgGiaTien='x\s*[\d]+\s*[dntrkgd]*\W'; 
$rgKeyWord='(de ghep|co|de co|de kep|bo ap kep|duoi|dau duoi|de dan|De dau duoi|dan|hai kep|de kep bang|le le|Tong tren|De tong chan|chan chan\W?25so\W?|de le le\W?25so\W?|Tong chan|de dit|Lo xien|kep bang|Cang|kepbang|keplech|tong|de tong|de dau dit|de he|Kep|3 cang|3cang|ba.cang|ba cang|he|dau|dit|dau dit|xien|kep|lo|de)*';
			
//////////////////////////////////////////////////////////
$sKQ = array();
$sKQ_cnt=0; $k=1;
$ColOPen='<tr><td>';
$ColCLose='</td></tr>';
/*
			$s1_Open='#';
			$s2_KeyWord=$GLOBALS['rgKeyWord']; 
			$s3_DaySo=$GLOBALS['rgDaySo'];//'[0-9\W]*';
			$s4_GiaTien=$GLOBALS['rgGiaTien'];//'x\s*[\d]+\s*[dntrkgd]*\W';//'x[\W]?[\d]+[\W]*[ndktr]*\W';//'[x][\W]?[\d]+[\S]?(k|n|tr|d)?\W';
			$s5_Close='#imU';
			
			$pattern = $s1_Open.$s2_KeyWord.$s3_DaySo.$s4_GiaTien.$s5_Close;
			preg_match_all($pattern, $subject, $matches) ;
			*/
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
function XuLy1muc(){
	$string='de 00,22,44,66,88 x250n.';
	echo $string.'<br/><br/>';
		$subject =$string;
		$s1_Open='#';
		$s5_Close='#imU';
		$s4_GiaTien=$GLOBALS['rgGiaTien'];
		$pattern = $s1_Open.$s4_GiaTien.$s5_Close;
		preg_match_all($pattern, $subject, $matches) ; 
	$tien=$matches[0][0];
		//print_r($matches);
		echo $tien.'<br/>';
		$string=str_replace($tien,';',$string);
		echo $string.'<br/>';
		
		$s3_DaySo='[0-9\W*]+';
		$pattern = $s1_Open.$s3_DaySo.$s5_Close;
		preg_match_all($pattern, $subject, $matches) ; 
		print_r($matches);
}
XuLy1muc();
return;
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
function SMSarray_cnt($string){
	// Đếm số tiền trong xâu đầu vào: string
	$cnt=0;
		$subject =$string;
		$s1_Open='#';
		$s5_Close='#imU';
		$s4_GiaTien=$GLOBALS['rgGiaTien'];//'x\s*[\d]+\s*[dntrkgd]*\W';//RG0: Gia tien;
		$pattern = $s1_Open.$s4_GiaTien.$s5_Close;
		preg_match_all($pattern, $subject, $matches) ; 
		//echo $string; print_r($matches);
		$cnt=count($matches[0]);
	return $cnt;
}// cach dung: $cnt=SMSarray_cnt($string);

function SMS2array($string){
	$cnt=SMSarray_cnt($string);
	$s1_Open='#';
	$s2_KeyWord=$GLOBALS['rgKeyWord'];;//'(kepbang|keplech|tong|de tong|de dau dit|de he|Kep|3 cang|3cang|ba.cang|ba cang|he|dau|dit|dau dit|xien|kep|lo|de)*';
	$s3_DaySo='[0-9\W]*';
	$s4_GiaTien=$GLOBALS['rgGiaTien'];;//'x\s*[\d]+\s*[dntrkgd]*\W';//'x[\W]?[\d]+[\W]*[ndktr]*\W';//'[x][\W]?[\d]+[\S]?(k|n|tr|d)?\W';
	$s5_Close='#imU';
	
	$pattern = $s1_Open.$s2_KeyWord.$s3_DaySo.$s4_GiaTien.$s5_Close;
	preg_match_all($pattern, $string, $matches) ;
	//echo $string.
	echo '('.strlen($string).':ký tự)'; 
	//print_r($matches);

	$L=0; $s=$string;$trClass='Odd';$k=0;
	echo '<table style="width:90%">';
	foreach($matches[0] as $r){
		$k++;
		if ($trClass=='Odd') { $trClass='Even'; } else { $trClass='Odd'; }
		echo '<tr class="row'.$trClass.'"><td>'.$k.'</td><td>'.$r.'</td></tr>';
		$L=$L+strlen($r);
		$s=str_replace($r,"",$s);
	}
	echo '</table>';	 
	echo '('.$L.':ký tự, còn thừa:'.$s.')<br/><br/><hr/>';
	return $matches[0];
}// Cach dung: $arr= SMS2array($string);

//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
function ChuanHoaCau($string){
	$string=strtolower($string);
	$string=ChuanHoaXau($string);
	//if($string[strlen($string)-1]!='.'){ $string = $string.'.'; }
	$string = $string.'.';
	$string = vn_str_filter($string);
	
	
	$string=str_replace('. .','.',$string);
	
	$string=str_replace('trieu','tr',$string);
	$string=str_replace('diem','d',$string);
	$string=str_replace(' nghin','n',$string);
	$string=str_replace('xjen','xien',$string);
	$string=str_replace('cag','cang',$string);
	$string=str_replace('đề','de',$string);
	$string=str_replace('djt','dit',$string);
	$string=str_replace('xjen','xien',$string);
	$string=str_replace('bag','bang',$string);
	$string=str_replace('xi2','Xien 2',$string);
	$string=str_replace('xi3','Xien 3',$string);
	$string=str_replace('xi4','Xien 4',$string);
	$string=str_replace('*','x',$string);
	$string=str_replace('nhá','',$string);
	$string=str_replace('kon','con',$string);
	$string=str_replace('&#10;','. ',$string);
	$string=str_replace('tjn','tin',$string);
	$string=str_replace('dd','dau dit',$string);
	$string=str_replace('DD','dau dit ',$string);
	$string=str_replace('chja ','chia ',$string);
	$string=str_replace('0.n','0n',$string);///////????nen hay k? x200.n322.355.311x100.n.346=>x200n322.355.311x100n.346
	$string=str_replace('dan de','de dan',$string);
	$string=str_replace('tg','tong',$string);
	
	$string=str_replace('xien','zzzzzz',$string);
	$string=str_replace('xi','xien',$string);
	$string=str_replace('zzzzzz','xien',$string);
	 
	$string=ChuanHoaGiaTien($string);
	$string = preg_replace('{(\W)\1+}','$1',$string); // loai bo dau., space, ' trung lap:(aaabbcccaaad  ....  2222 00000         d.. dss,, ddde'''=>aaabbcccaaad . 2222 00000 d. dss, ddde')
	
	return $string;
}//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
function ChuanHoaGiaTien($string){
			$subject =$string;
			$s1_Open='#';
			$s4_GiaTien='(x\s*[\d]+\.[dntrkgd]*(?=\W))|(x\s*[\d]+\s[dntrkgd]*(?=\W))';
			$s5_Close='#imU';			
			$pattern = $s1_Open.$s4_GiaTien.$s5_Close;
			preg_match_all($pattern, $subject, $matches) ; 
			foreach($matches[0] as $s){
				 $s1=str_replace(' ','',$s);
				 $s1=str_replace('.','',$s);
				 $s1=' '.$s1.'';
				 $string=str_replace($s,$s1,$string);
			}

			$subject =$string;
			$s4_GiaTien='x\s[\d]+[dntrkgd]*(?=\W)';
			$pattern = $s1_Open.$s4_GiaTien.$s5_Close;
			preg_match_all($pattern, $subject, $matches) ; 
			foreach($matches[0] as $s){
				 $s1=str_replace(' ','',$s);
				 $s1=' '.$s1.'';
				 $string=str_replace($s,$s1,$string);
			}

	return $string;
}
// Cach dung: $string=ChuanHoaGiaTien($string);
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
function ChuanHoaXau($string){
//Loai bo: Tin xx:, Txx ở đầu câu.	
	$string=trim($string);
	$s1_Open='#';
	$s5_Close='#imU';			
	$subject =$string;
	$s4_GiaTien='(^Tin[\d]+\s)|(^Tin\s?[\d]+[,.])|(^Tin\s?[\d]+:)|(^T\s?[\d]+:?)';
	$pattern = $s1_Open.$s4_GiaTien.$s5_Close;
	preg_match_all($pattern, $subject, $matches) ; 
	foreach($matches[0] as $s){
		 $string=str_replace($s,'',$string);
	}
return $string;
}
// Cach dung: $string=ChuanHoaXau($string);
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
 
echo date("l jS \of F Y h:i:s A")."<br/><br/>";
//echo '<table width="90%">';
$SMS_cnt=1;
 foreach (glob("./Data/*.xml") as $filename) {
	$subject = file_get_contents($filename);
	$pattern = '#(?<=body=")(.*)(?=" toa=)#imU';
	preg_match_all($pattern, $subject, $matches, PREG_OFFSET_CAPTURE, 3);
	foreach ( $matches[0] as $str){
		if(strpos($str[0], "x")){ //echo $k[0].'<br/><br/>';
			 
////////////////////////////////////////////////
			//$file=vn_str_filter($file)
			$string = $str[0];
			$string = ChuanHoaCau($string);
			$string0=$string; // Ddự trữ xâu gốc để phân tách thành các cụm
			
			$subject = $string;
			
			$s1_Open='#';
			$s2_KeyWord=$GLOBALS['rgKeyWord']; 
			$s3_DaySo=$GLOBALS['rgDaySo'];//'[0-9\W]*';
			$s4_GiaTien=$GLOBALS['rgGiaTien'];//'x\s*[\d]+\s*[dntrkgd]*\W';//'x[\W]?[\d]+[\W]*[ndktr]*\W';//'[x][\W]?[\d]+[\S]?(k|n|tr|d)?\W';
			$s5_Close='#imU';
			
			$pattern = $s1_Open.$s2_KeyWord.$s3_DaySo.$s4_GiaTien.$s5_Close;
			preg_match_all($pattern, $subject, $matches) ;
			
			// echo $matches[0][0];
			$cnt=0;
			foreach($matches[0] as $s){
				$cnt++;
				 if($k%2==0) $string=str_replace($s,'<span class="vang">'.$s.'</span>',$string);
				 else 		 $string=str_replace($s,'<span class="xanh">'.$s.'</span>',$string);
				 $k=$k+1;
			 }
			 if($cnt>=0){
				 echo $str[0].'<br/><br/>';
				 echo 'SMS số: '. $SMS_cnt++ .':<br/>';
				// echo '<table style="width:98%"><tr><td>'.$string. '</td></tr></table>';
				 $newtext = wordwrap($string, 100,"\n");
				 echo "$newtext";
			 }
			 $arr= SMS2array($string0);
			 
			 $sKQ[$sKQ_cnt]= $string;
			 $sKQ_cnt++;
			 
			 //if($sKQ_cnt>10)return; // ngừng khi in ra 10 KQ đê xem
////////////////////////////////////////////////
		}
	}
}
//echo '</table>';
//print_r($sKQ_cnt);
 return;
?>

<?php
	$stt=1;
 
 foreach (glob("./Data/*.xml") as $filename) {
    //echo "$filename   <br/><br/>";
	$get = file_get_contents($filename);
 
	$subject = $get;
	$pattern = '#(?<=body=")(.*)(?=" toa=)#imU';

	preg_match_all($pattern, $subject, $matches, PREG_OFFSET_CAPTURE, 3);
	//print_r($matches);

	//echo '<center><table border=1 width=90% >';
	
	foreach ( $matches[0] as $k){
		 if(strpos($k[0], "x")){
//			 echo '<tr><td>'.$stt.'</td><td>'.$k[0].'</td></tr>';
			echo $k[0];
			echo '<br/><br/>';
			$stt=$stt+1;
			
			
		 }
	 }
 	 
	echo '</table></center>';
}

///////////////////////////////////////////////////////////////
//--------------------------------------------------------------------------
//hàm đổi chữ TV có dấu ==> không dấu
	function vn_str_filter ($str){
        $unicode = array(
            'a'=>'á|à|ả|ã|ạ|ă|ắ|ặ|ằ|ẳ|ẵ|â|ấ|ầ|ẩ|ẫ|ậ',
            'd'=>'đ|₫',
            'e'=>'é|è|ẻ|ẽ|ẹ|ê|ế|ề|ể|ễ|ệ', //mã gõ trên PC
			'e'=>'ệ|ề|ề|ế|ẻ|é|ê|é|ể|ệ',		  // Mã gõ trên phone, PC không xử lý được	
            'i'=>'í|ì|ỉ|ĩ|ị',
			'i'=>'í|í|ì',  //TA
            'o'=>'ó|ò|ỏ|õ|ọ|ô|ố|ồ|ổ|ỗ|ộ|ơ|ớ|ờ|ở|ỡ|ợ',
			'o'=>'ổ|ô',  //TA
            'u'=>'ú|ù|ủ|ũ|ụ|ư|ứ|ừ|ử|ữ|ự',
            'y'=>'ý|ỳ|ỷ|ỹ|ỵ',
			'A'=>'Á|À|Ả|Ã|Ạ|Ă|Ắ|Ặ|Ằ|Ẳ|Ẵ|Â|Ấ|Ầ|Ẩ|Ẫ|Ậ',
            'D'=>'Đ',
            'E'=>'É|È|Ẻ|Ẽ|Ẹ|Ê|Ế|Ề|Ể|Ễ|Ệ',
            'I'=>'Í|Ì|Ỉ|Ĩ|Ị',
            'O'=>'Ó|Ò|Ỏ|Õ|Ọ|Ô|Ố|Ồ|Ổ|Ỗ|Ộ|Ơ|Ớ|Ờ|Ở|Ỡ|Ợ',
            'U'=>'Ú|Ù|Ủ|Ũ|Ụ|Ư|Ứ|Ừ|Ử|Ữ|Ự',
            'Y'=>'Ý|Ỳ|Ỷ|Ỹ|Ỵ',
        );
       foreach($unicode as $nonUnicode=>$uni){
            $str = preg_replace("/($uni)/i", $nonUnicode, $str);  
       } 
		return $str;
    }
// Sử dụng:   $file=vn_str_filter($file);
//--------------------------------------------------------------------------
?>

</body>
</html>



