<!DOCTYPE html>
<meta charset="utf-8">
<?php
$get = file_get_contents('./Data/02-sms-20151002194503.xml');
 
 foreach (glob("./Data/*.xml") as $filename) {
    echo "$filename   " .  "<br/><br/>";
 }
echo '<br/><br/>';

$subject = $get;
$pattern = '#(?<=body=")(.*)(?=" toa=)#imU';

preg_match_all($pattern, $subject, $matches, PREG_OFFSET_CAPTURE, 3);
//print_r($matches);
$stt=1;
echo '<center><table border="1" width=90%>';
 foreach ( $matches[0] as $k){
	 if(strpos($k[0], "x")){
		 echo '<tr><td>'.$stt.'</td><td>'.$k[0].'</td></tr>';
		 $stt=$stt+1;
	 }
 }
 echo '</table></center>';
?>