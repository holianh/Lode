<?php
//taFuncs.php
// Cac ham thu vien dung chung
$rgDaySo='[0-9\W]*';
$rgGiaTien='x\s*[\d]+\s*[dntrkgd]*\W'; 
$rgKeyWord='((de dan tu [0-9\W]* cua tong (chan|le)[0-9so\W]*)|de ghep|co|de co|de kep|bo ap kep|duoi|dau duoi|de dan|De dau duoi|dan|hai kep|de kep bang|le le|Tong tren|De tong chan|chan chan\W?25so\W?|de le le\W?25so\W?|Tong chan|de dit|Lo xien|kep bang|Cang|kepbang|keplech|tong|de tong|de dau dit|de he|Kep|3 cang|3cang|ba.cang|ba cang|he|dau|dit|dau dit|xien|kep|lo|de)*';

function SMSarray_cnt($string){
	// Đếm số tiền trong xâu đầu vào: string
	$cnt=0;
		$subject =$string;
		$s1_Open='#';
		$s5_Close='#imU';
		$s4_GiaTien=$GLOBALS['rgGiaTien'];//'x\s*[\d]+\s*[dntrkgd]*\W';//RG0: Gia tien;
		$pattern = $s1_Open.$s4_GiaTien.$s5_Close;
		preg_match_all($pattern, $subject, $matches) ; 
		//echo $string; print_r($matches);
		$cnt=count($matches[0]);
	return $cnt;
}// cach dung: $cnt=SMSarray_cnt($string);

function SMS2array($string){
	$cnt=SMSarray_cnt($string);
	$s1_Open='#';
	$s2_KeyWord=$GLOBALS['rgKeyWord'];;//'(kepbang|keplech|tong|de tong|de dau dit|de he|Kep|3 cang|3cang|ba.cang|ba cang|he|dau|dit|dau dit|xien|kep|lo|de)*';
	$s3_DaySo='[0-9\W]*';
	$s4_GiaTien=$GLOBALS['rgGiaTien'];;//'x\s*[\d]+\s*[dntrkgd]*\W';//'x[\W]?[\d]+[\W]*[ndktr]*\W';//'[x][\W]?[\d]+[\S]?(k|n|tr|d)?\W';
	$s5_Close='#imU';
	
	$pattern = $s1_Open.$s2_KeyWord.$s3_DaySo.$s4_GiaTien.$s5_Close;
	preg_match_all($pattern, $string, $matches) ;
	//echo $string.
	//echo '('.strlen($string).':ký tự)'; 
	//print_r($matches);

	$L=0; $s=$string;$trClass='Odd';$k=0;
	echo '<table style="width:95%">';
	$loai='';
	foreach($matches[0] as $r){
		$Sout=XuLy1muc($loai,$r);
		$k++;
		if ($trClass=='Odd') { $trClass='Even'; } else { $trClass='Odd'; }
		echo '<tr class="row'.$trClass.'"><td>'.$k.'</td><td>'.$r.'<br/>'.$Sout.'</td></tr>';
		$L=$L+strlen($r);
		$s=str_replace($r,"",$s);
	}
	echo '</table>';	 
	echo '('.$L.':ký tự, còn thừa:'.$s.')<br/><br/>';
	return $matches[0];
}// Cach dung: $arr= SMS2array($string);
 
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
function ChuanHoaCau($string,$id=null){
	$string=strtolower($string);
	$string=ChuanHoaXau($string);
	//if($string[strlen($string)-1]!='.'){ $string = $string.'.'; }
	$string = $string.'.';
	$string = vn_str_filter($string);
	
	$replace = array( 
		'. .'	=>	'.'	,
		'trieu'	=>	'tr'	,
		'diem'	=>	'd'	,
		' nghin'=>	'n'	,
		'xjen'	=>	'xien'	,
		'cag'	=>	'cang'	,
		'đề'	=>	'de'	,
		'djt'	=>	'dit'	,
		'xjen'	=>	'xien'	,
		'bag'	=>	'bang'	,
		'xi2'	=>	'Xien 2'	,
		'xi3'	=>	'Xien 3'	,
		'xi4'	=>	'Xien 4'	,
		'*'		=>	'x'	,
		'nhá'	=>	''	,
		'kon'	=>	'con'	,
		'&#10;'	=>	'. '	,
		'tjn'	=>	'tin'	,
		'dd'	=>	'dau dit'	,
		'DD'	=>	'dau dit '	,
		'chja '	=>	'chia '	,
		'0.n'	=>	'0n'	,
		'dan de'	=>	'de dan'	,
		'tg'	=>	'tong'	,
		'xien'	=>	'xi'	,
		'x '	=>	'x'
	); 
	 
	$string=strtr($string,$replace); //str_replace(array_keys($replace), array_values($replace), $subject);// 	 
	$string=ChuanHoaGiaTien($string,$id);
	
	$string = preg_replace('{(\W)+}','$1 ',$string); //thay the dau cau => dau cau + space: {\W} => {\W }
	$string = preg_replace('{(\W)\1+}','$1',$string); // loai bo dau., space, ' trung lap:(aaabbcccaaad  ....  2222 00000         d.. dss,, ddde'''=>aaabbcccaaad . 2222 00000 d. dss, ddde')
	
	return $string;
}//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
function ChuanHoaGiaTien($string,$id=null){	
			$subject =$string;
			$s1_Open='#';
			$s4_GiaTien='(x\s*[\d]+\.[dntrkgd]*(?=\W))|(x\s*[\d]+\s[dntrkgd]*(?=\W))';
			$s5_Close='#imU';			
			$pattern = $s1_Open.$s4_GiaTien.$s5_Close;
			preg_match_all($pattern, $subject, $matches) ; 
			foreach($matches[0] as $s){
				 $s1=str_replace(' ','n',$s);
				 $s1=str_replace('.','n',$s);
				 $s1=' '.$s1.'';
				 $string=str_replace($s,$s1,$string);
				 if($id>0) echo "(($s1))";
				 
			}

			$subject =$string;
			$s4_GiaTien='x\s[\d]+[dntrkgd]*(?=\W)';
			$pattern = $s1_Open.$s4_GiaTien.$s5_Close;
			preg_match_all($pattern, $subject, $matches) ; 
			foreach($matches[0] as $s){
				 $s1=str_replace(' ','',$s);
				 $s1=' '.$s1.'';
				 $string=str_replace($s,$s1,$string);
				 
				 if($id>0) echo "(($s1))";
				 
			}

	return $string;
}
// Cach dung: $string=ChuanHoaGiaTien($string);
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
function ChuanHoaXau($string){
//Loai bo: Tin xx:, Txx ở đầu câu.	
	$string=trim($string);
	$s1_Open='#';
	$s5_Close='#imU';			
	$subject =$string;
	$s4_GiaTien='(^Tin[\d]+\s)|(^Tin\s?[\d]+[,.])|(^Tin\s?[\d]+:)|(^T\s?[\d]+:?)';
	$pattern = $s1_Open.$s4_GiaTien.$s5_Close;
	preg_match_all($pattern, $subject, $matches) ; 
	foreach($matches[0] as $s){
		 $string=str_replace($s,'',$string);
	}
return $string;
}
// Cach dung: $string=ChuanHoaXau($string);
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx






?>