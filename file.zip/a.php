<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
	span.vang { background-color: yellow; }
	span.xanh { background-color: cyan; }
</style>
</head>
<body>

<?php
////////////// remove space:
$string=$subject ='Đề đề ĐỀ kep bang x      20n  De 60.2x  1 tr de 7x  50  n . De he 2.01x 250n. De 20.21.06.23.24.42.4.6x 250n. De dan 27x 150n. Lo 38x 250d. Lo 73x 125d.
';	
$string=vn_str_filter($string);

function ChuanHoaGiaTien($string){
			$subject =$string;
			$s1_Open='#';
			$s4_GiaTien='x\s*[\d]+\s[dntrkgd]*(?=\W)';// phai co space.
			$s5_Close='#imU';	
			$pattern = $s1_Open.$s4_GiaTien.$s5_Close;
			preg_match_all($pattern, $subject, $matches) ; 
			print_r($matches) ; 
			foreach($matches[0] as $s){
				 $s1=str_replace(' ','',$s);
				 echo $s1.'<br/>';
				 $s1=' '.$s1.'.';
				 //$string=str_replace($s,$s1,$string);
				 $string=str_replace($s,'<span class="vang">'.$s1.'</span>',$string);
			}
   return $string;
}
// Cach dung: 
$string=ChuanHoaGiaTien($string);
echo $string;

return;
$str = "Final result: aaabbcccaaad  ....  2222 00000         d.. dss,, ddde'''";
$str = preg_replace('{(\W)\1+}','$1',$str);
//Result: abcad d d d d d d de'
echo $str;
function vn_str_filter ($str){
        $unicode = array(
            'a'=>'á|à|ả|ã|ạ|ă|ắ|ặ|ằ|ẳ|ẵ|â|ấ|ầ|ẩ|ẫ|ậ',
            'd'=>'đ',
            'e'=>'é|è|ẻ|ẽ|ẹ|ê|ế|ề|ể|ễ|ệ',
            'i'=>'í|ì|ỉ|ĩ|ị',
            'o'=>'ó|ò|ỏ|õ|ọ|ô|ố|ồ|ổ|ỗ|ộ|ơ|ớ|ờ|ở|ỡ|ợ',
            'u'=>'ú|ù|ủ|ũ|ụ|ư|ứ|ừ|ử|ữ|ự',
            'y'=>'ý|ỳ|ỷ|ỹ|ỵ',
			'A'=>'Á|À|Ả|Ã|Ạ|Ă|Ắ|Ặ|Ằ|Ẳ|Ẵ|Â|Ấ|Ầ|Ẩ|Ẫ|Ậ',
            'D'=>'Đ',
            'E'=>'É|È|Ẻ|Ẽ|Ẹ|Ê|Ế|Ề|Ể|Ễ|Ệ',
            'I'=>'Í|Ì|Ỉ|Ĩ|Ị',
            'O'=>'Ó|Ò|Ỏ|Õ|Ọ|Ô|Ố|Ồ|Ổ|Ỗ|Ộ|Ơ|Ớ|Ờ|Ở|Ỡ|Ợ',
            'U'=>'Ú|Ù|Ủ|Ũ|Ụ|Ư|Ứ|Ừ|Ử|Ữ|Ự',
            'Y'=>'Ý|Ỳ|Ỷ|Ỹ|Ỵ',
        );
       foreach($unicode as $nonUnicode=>$uni){
            $str = preg_replace("/($uni)/i", $nonUnicode, $str);  
       }
	   
	   //$str=str_replace('Dè','De',$str);
		return $str;
    }
?>